const mongoose = require("mongoose");

const partnerSchema = mongoose.Schema({
    name: {
        type: String,
        required:true

    },
    typeOfContract:{
        type:String,
        required:true

    },
    duration:{
        type:Number,
        required:true

    },
    finishDate:{
        type: Number,
        required: true
    },
    phone:{
        type:Number,
        required:true
    }
});

module.exports = mongoose.model('Patrocinadores',partnerSchema);