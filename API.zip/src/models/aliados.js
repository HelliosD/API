const mongoose = require("mongoose");

const alliesSchema = mongoose.Schema({
    name: {
        type: String,
        required:true

    },
    allySince:{
        type:Number,
        required:true

    },
    superpower:{
        type:String,
        required:true

    },    
    phone:{
        type:Number,
        required:true
    }
});

module.exports = mongoose.model('Aliados',alliesSchema);