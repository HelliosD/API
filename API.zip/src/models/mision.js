const mongoose = require("mongoose");

const misionSchema = mongoose.Schema({
    name: {
        type: String,
        required:true

    },
    date:{
        type:String,
        required:true

    },
    description:{
        type:String,
        required:true

    }
});

module.exports = mongoose.model('Misiones',misionSchema);