const mongoose = require("mongoose");

const villianSchema = mongoose.Schema({
    "name": {
        type: String,
        required:true

    },
    "age":{
        type:Number,
        required:true

    },
    "superPower":{
        type:String,
        required:true

    }
});

module.exports = mongoose.model('Villanos',villianSchema);