const mongoose = require("mongoose");

const peopleSavedSchema = mongoose.Schema({
    name: {
        type: String,
        required:true

    },
    age:{
        type:Number,
        required:true

    },
    dateOfSalvation:{
        type:String,
        required:true

    },    
    phone:{
        type:Number,
        required:true
    }
});

module.exports = mongoose.model('Salvados',peopleSavedSchema);