const express = require('express');
const mongoose = require('mongoose');
require("dotenv").config();
const partnerRoutes = require("./routes/patrocinadores.js")
const alliesRoutes = require("./routes/aliados");
const teamMateRoutes = require("./routes/companeros");
const peopleSavedRoutes = require("./routes/personas");
const villianRoutes = require("./routes/villano");
const misionRoutes = require("./routes/mision");
const cors = require("./cors/index");


const app = express();
app.use(cors);
const port = process.env.port || 9000;




//Middleware
app.use(express.json());
app.use('/api',partnerRoutes);
app.use('/api', alliesRoutes);
app.use('/api',teamMateRoutes);
app.use('/api',peopleSavedRoutes);
app.use('/api',villianRoutes);
app.use('/api',misionRoutes);


//routes

app.get('/',(req, res)=>{
    res.json()
    
   
},

);


// conexion mongodb

mongoose.connect(
    process.env.MONGODB_URI).then(()=>console.log("Connected to MONGODB")).catch((error)=>console.error);

app.listen(port, () => console.log('server listening',port));