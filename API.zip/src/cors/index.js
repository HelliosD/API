const cors = require('cors');

const corsOption = {
    origin: 'http://localhost:3000',
    optionSuccesStatus: 200,
};

module.exports = cors(corsOption);