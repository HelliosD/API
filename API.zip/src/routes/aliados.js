const express = require("express");
const router = express.Router();
const alliesSchema = require("../models/aliados");

// Create

router.post('/aliados', (req,res)=>{
    const ally = alliesSchema(req.body);
    ally.save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get all users
router.get('/aliados', (req,res)=>{
    alliesSchema
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get a user
router.get('/aliados/:id', (req,res)=>{
    const{id}= req.params;
    alliesSchema
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

//update
router.put('/aliados/:id', (req,res)=>{
    const{id}= req.params;
    const{name,allySince,superpower,phone}= req.body; 
    alliesSchema
    .updateOne({_id:id},{$set:{name,allySince,superpower,phone}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});
//delete
router.delete('/aliados/:id', (req,res)=>{
    const{id}= req.params;
     
    alliesSchema
    .deleteOne({_id:id})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

module.exports= router;