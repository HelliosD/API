const express = require("express");
const router = express.Router();
const peopleSavedSchema = require("../models/persona");

// Create

router.post('/persona', (req,res)=>{
    const person = peopleSavedSchema(req.body);
    person.save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get all users
router.get('/persona', (req,res)=>{
    peopleSavedSchema
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get a user
router.get('/persona/:id', (req,res)=>{
    const{id}= req.params;
    peopleSavedSchema
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

//update
router.put('/persona/:id', (req,res)=>{
    const{id}= req.params;
    const{name,age,dateOfSalvation,phone}= req.body; 
    peopleSavedSchema
    .updateOne({_id:id},{$set:{name,age,dateOfSalvation,phone}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});
//delete
router.delete('/persona/:id', (req,res)=>{
    const{id}= req.params;
     
    peopleSavedSchema
    .deleteOne({_id:id})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

module.exports= router;