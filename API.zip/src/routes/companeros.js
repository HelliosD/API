const express = require("express");
const router = express.Router();
const teamMateSchema = require("../models/companeros");

// Create

router.post('/companeros', (req,res)=>{
    const mate = teamMateSchema(req.body);
    mate.save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get all users
router.get('/companeros', (req,res)=>{
    teamMateSchema
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get a user
router.get('/companeros/:id', (req,res)=>{
    const{id}= req.params;
    teamMateSchema
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

//update
router.put('/companeros/:id', (req,res)=>{
    const{id}= req.params;
    const{name,mateSince,superpower,phone}= req.body; 
    teamMateSchema
    .updateOne({_id:id},{$set:{name,mateSince,superpower,phone}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});
//delete
router.delete('/companeros/:id', (req,res)=>{
    const{id}= req.params;
     
    teamMateSchema
    .deleteOne({_id:id})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

module.exports= router;