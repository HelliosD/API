const express = require("express");
const router = express.Router();
const misionSchema = require("../models/mision");

// Create

router.post('/mision', (req,res)=>{
    const mision = misionSchema(req.body);
    mision.save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get all users
router.get('/mision', (req,res)=>{
    misionSchema
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get a user
router.get('/mision/:id', (req,res)=>{
    const{id}= req.params;
    misionSchema
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

//update
router.put('/mision/:id', (req,res)=>{
    const{id}= req.params;
    const{name,date,description}= req.body; 
    misionSchema
    .updateOne({_id:id},{$set:{name,date,description}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});
//delete
router.delete('/mision/:id', (req,res)=>{
    const{id}= req.params;
     
    name,date,description
    .deleteOne({_id:id})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

module.exports= router;