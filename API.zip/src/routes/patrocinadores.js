const express = require("express");
const router = express.Router();
const partnerSchema = require("../models/patrocinadores");

// Create

router.post('/patrocinadores', (req,res)=>{
    const partner = partnerSchema(req.body);
    partner.save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get all users
router.get('/patrocinadores', (req,res)=>{
    partnerSchema
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get a user
router.get('/patrocinadores/:id', (req,res)=>{
    const{id}= req.params;
    partnerSchema
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

//update
router.put('/patrocinadores/:id', (req,res)=>{
    const{id}= req.params;
    const{name,TypeOfContract,duration,finishDate,phone}= req.body; 
    partnerSchema
    .updateOne({_id:id},{$set:{name,TypeOfContract,duration,finishDate,phone}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});
//delete
router.delete('/patrocinadores/:id', (req,res)=>{
    const{id}= req.params;
     
    partnerSchema
    .deleteOne({_id:id})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

module.exports= router;