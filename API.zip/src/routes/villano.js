const express = require("express");
const router = express.Router();
const villianSavedSchema = require("../models/villano");

// Create

router.post('/villano', (req,res)=>{
    const villian = villianSavedSchema(req.body);
    villian.save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get all users
router.get('/villano', (req,res)=>{
    villianSavedSchema
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

// get a user
router.get('/villano/:id', (req,res)=>{
    const{id}= req.params;
    villianSavedSchema
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

//update
router.put('/villano/:id', (req,res)=>{
    const{id}= req.params;
    const{name,age,superPower}= req.body; 
    villianSavedSchema
    .updateOne({_id:id},{$set:{name,age,superPower}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});
//delete
router.delete('/villano/:id', (req,res)=>{
    const{id}= req.params;
     
    villianSavedSchema
    .deleteOne({_id:id})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message: error}));
});

module.exports= router;